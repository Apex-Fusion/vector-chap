module Cardano.Ledger.Alonzo.Data
  {-# DEPRECATED "This module has been split into two \"Cardano.Ledger.Alonzo.TxAuxData\" and \"Cardano.Ledger.Plutus.Data\"" #-} (
  module X,
)
where

import Cardano.Ledger.Alonzo.TxAuxData as X
import Cardano.Ledger.Plutus.Data as X
