{-# OPTIONS_GHC -F -pgmF tasty-discover -optF --hide-successes #-}
