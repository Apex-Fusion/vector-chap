module Cardano.Ledger.Shelley.Metadata
  {-# DEPRECATED "Use 'import Cardano.Ledger.Shelley.TxAuxData' instead" #-} (
  module X,
)
where

import Cardano.Ledger.Shelley.TxAuxData as X
