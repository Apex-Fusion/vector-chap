module Cardano.Ledger.UMapCompact
  {-# DEPRECATED "Use Cardano.Ledger.UMap instead" #-}
  (module X)
where

import Cardano.Ledger.UMap as X
