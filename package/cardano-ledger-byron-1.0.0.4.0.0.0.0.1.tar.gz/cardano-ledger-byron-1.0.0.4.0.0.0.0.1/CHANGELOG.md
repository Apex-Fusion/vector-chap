# Revision history for `cardano-ledger-byron`

## 1.0.0.4

*

## 1.0.0.3

* Update `streaming-binary` dependency to 0.4.

## 1.0.0.2

*

## 1.0.0.1

* Make it build with `ghc-9.6`.

## 1.0.0.0

* First properly versioned release.
